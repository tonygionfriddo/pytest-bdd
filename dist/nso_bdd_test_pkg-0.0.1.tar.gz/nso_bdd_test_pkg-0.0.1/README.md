# pytest-bdd
pytest behavioral driven development practice
